hddnameS = "GENERIC IDE DISK"
hddspace = 8000
hddspaceS = "8MB"
kajsaed = True