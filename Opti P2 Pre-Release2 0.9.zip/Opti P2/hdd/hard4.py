hddnameS = "GENERIC IDE DISK"
hddspace = 4000
hddspaceS = "4MB"
kajsaed = True