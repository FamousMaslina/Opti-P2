hddnameS = "GENERIC IDE DISK"
hddspace = 32000
hddspaceS = "32MB"
kajsaed = True