hddnameS = "GENERIC IDE DISK"
hddspace = 16000
hddspaceS = "16MB"
kajsaed = True