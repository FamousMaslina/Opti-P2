mon = 'vgamonitor.py'
