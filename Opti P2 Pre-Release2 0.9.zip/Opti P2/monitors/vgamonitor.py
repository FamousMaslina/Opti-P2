monitorName = "VGA Monitor"
monitorRes = "640x480"
monitorHz = "60Hz"
monitorHzI = 60
monitorAspectRation = "4:3"
mmmnni = True