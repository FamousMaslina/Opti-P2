soundName = "AdLib Gold"
soundChip = "Yamaha YMF262"
soundDF = "12-bit PCM"
soundNumCh = "2"
stereo = True
soundExp = "ISA"
ssundc = True