modemname = "14.4kbps Modem"
modemspeed = 14.4
modemspeeds = "14.4kbps"
dialupadp = "Basic Dial-Up Adapter"
saiop = True