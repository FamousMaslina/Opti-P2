keyName = "BASIC PS/2 KEYBOARD"
kkeyb = True