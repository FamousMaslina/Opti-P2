hd = 'hard64.py'
