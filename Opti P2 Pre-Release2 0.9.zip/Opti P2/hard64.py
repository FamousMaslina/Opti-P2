hddnameS = "GENERIC IDE DISK"
hddspace = 64000
hddspaceS = "64MB"
kajsaed = True