cName = "NEC D70325L-8"
cFreq = 8
cFreqS = "8"
cFreqUnit = "MHz"
asdawd2k3a403 = "286"