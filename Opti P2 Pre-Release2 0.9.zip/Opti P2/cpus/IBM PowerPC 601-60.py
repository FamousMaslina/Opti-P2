cName = "IBM PowerPC 601"
cFreq = 60
cFreqS = "60"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"