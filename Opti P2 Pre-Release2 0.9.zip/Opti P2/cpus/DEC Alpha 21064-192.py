cName = "DEC Alpha 21064"
cFreq = 192
cFreqS = "192"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"