cName = "386 Based Processor"
cFreq = 35
cFreqS = "35"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"