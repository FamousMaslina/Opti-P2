cName = "8088 Based Processor"
cFreq = 4.77
cFreqS = "4.77"
cFreqUnit = "MHz"
asdawd2k3a403 = "8088"