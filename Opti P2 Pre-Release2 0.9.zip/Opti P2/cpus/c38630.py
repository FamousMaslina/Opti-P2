cName = "386 Based Processor"
cFreq = 30
cFreqS = "30"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"