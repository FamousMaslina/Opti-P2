cName = "MIPS R3000"
cFreq = 34
cFreqS = "34"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"