cName = "186 Based Processor"
cFreq = 2
cFreqS = "2"
cFreqUnit = "MHz"
asdawd2k3a403 = "186"