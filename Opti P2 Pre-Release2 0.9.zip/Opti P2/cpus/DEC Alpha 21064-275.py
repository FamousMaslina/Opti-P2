cName = "DEC Alpha 21064"
cFreq = 275
cFreqS = "275"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"