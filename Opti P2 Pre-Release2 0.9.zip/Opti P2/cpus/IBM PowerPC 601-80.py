cName = "IBM PowerPC 601"
cFreq = 80
cFreqS = "80"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"