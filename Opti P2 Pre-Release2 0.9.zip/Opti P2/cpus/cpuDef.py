cName = "Basic Processor" #CPU name that appears in BIOS menu and info command. You can put anything in here as long it is a string
cFreq = 6 #Measured in MegaHertz. And this is the int value that also affects the loading times!!!
cFreqS = "6" #Same as cFreq, but in string. This is used for the BIOS reading and OS info, just like cName. Should be the same as cFreq.
cFreqUnit = "MHz" #This goes after cFreqS in BIOS readings and OS.
asdawd2k3a403 = "286" #Hmmmm... Maybe, just maybe...