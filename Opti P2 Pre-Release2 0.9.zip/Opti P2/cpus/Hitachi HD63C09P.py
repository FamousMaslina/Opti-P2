cName = "Hitachi HD63C09P"
cFreq = 3
cFreqS = "3"
cFreqUnit = "MHz"
asdawd2k3a403 = "186"