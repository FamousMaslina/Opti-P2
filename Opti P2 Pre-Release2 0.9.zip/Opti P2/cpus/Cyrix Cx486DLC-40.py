cName = "Cyrix Cx486DLC"
cFreq = 40
cFreqS = "40"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"