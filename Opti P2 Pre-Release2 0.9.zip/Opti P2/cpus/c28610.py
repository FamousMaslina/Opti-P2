cName = "286 Based Processor"
cFreq = 10
cFreqS = "10"
cFreqUnit = "MHz"
asdawd2k3a403 = "286"