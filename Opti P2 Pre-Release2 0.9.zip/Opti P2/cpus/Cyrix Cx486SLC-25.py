cName = "Cyrix Cx486SLC"
cFreq = 25
cFreqS = "25"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"