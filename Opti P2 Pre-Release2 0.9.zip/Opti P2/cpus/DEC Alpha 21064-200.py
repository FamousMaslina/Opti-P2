cName = "DEC Alpha 21064"
cFreq = 200
cFreqS = "200"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"