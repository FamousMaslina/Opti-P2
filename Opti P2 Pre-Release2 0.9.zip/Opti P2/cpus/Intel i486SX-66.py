cName = "Intel i486SX"
cFreq = 66
cFreqS = "66"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"