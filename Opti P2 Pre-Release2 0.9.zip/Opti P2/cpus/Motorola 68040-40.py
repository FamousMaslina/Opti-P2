cName = "Motorola 68040"
cFreq = 40
cFreqS = "40"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"