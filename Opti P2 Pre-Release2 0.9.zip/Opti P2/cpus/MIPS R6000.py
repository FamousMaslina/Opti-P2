cName = "MIPS R6000"
cFreq = 80
cFreqS = "80"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"