cName = "Philips SCC68070ADB"
cFreq = 18
cFreqS = "18"
cFreqUnit = "MHz"
asdawd2k3a403 = "186"