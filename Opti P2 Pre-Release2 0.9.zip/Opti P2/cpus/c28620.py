cName = "286 Based Processor"
cFreq = 20
cFreqS = "20"
cFreqUnit = "MHz"
asdawd2k3a403 = "286"