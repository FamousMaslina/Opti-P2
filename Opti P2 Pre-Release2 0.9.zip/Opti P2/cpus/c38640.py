cName = "386 Based Processor"
cFreq = 40
cFreqS = "40"
cFreqUnit = "MHz"
asdawd2k3a403 = "386"