cName = "286 Based Processor"
cFreq = 12
cFreqS = "12"
cFreqUnit = "MHz"
asdawd2k3a403 = "286"