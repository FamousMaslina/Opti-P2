floname = "3.5 Floppy Drive"
firin = True