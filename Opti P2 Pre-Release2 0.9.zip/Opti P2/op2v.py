op2VER = "Pre-Release2 0.9"
op2VERI = 0.8
op2VERSTRING = "1B"